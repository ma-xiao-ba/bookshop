package com.bs.mapper;

import java.util.List;

import com.bs.bean.BookTypes;

public interface BookTypeMapper {
	public List<BookTypes> quaryBookType();
}
