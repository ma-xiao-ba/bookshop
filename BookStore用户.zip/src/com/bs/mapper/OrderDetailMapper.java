package com.bs.mapper;

import com.bs.bean.OrderDetail;


public interface OrderDetailMapper {
	public void addOrderDetail(OrderDetail orderDetail);
}
