package com.bs.mapper;

import com.bs.bean.User;

public interface UserMapper {
	public Integer login(User user);
}
