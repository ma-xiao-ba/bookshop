package com.bs.mapper;

import com.bs.bean.Cart;

public interface CartMapper {
	public void addCart(Cart cart);
}
