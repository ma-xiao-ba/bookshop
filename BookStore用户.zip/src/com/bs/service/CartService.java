package com.bs.service;

import com.bs.bean.Cart;

public interface CartService {
	public void addCart(Cart cart);
}
