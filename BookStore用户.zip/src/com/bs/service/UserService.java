package com.bs.service;

import com.bs.bean.User;

public interface UserService {
	public boolean login(User user);
}
