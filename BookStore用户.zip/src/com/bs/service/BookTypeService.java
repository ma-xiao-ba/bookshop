package com.bs.service;

import java.util.List;

import com.bs.bean.BookTypes;

public interface BookTypeService {
	public List<BookTypes> quaryBookType();
}
