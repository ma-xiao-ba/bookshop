package com.bs.service;


import com.bs.bean.OrderDetail;

public interface OrderDetailService {
	public void addOrderDetail(OrderDetail orderDetail);
}
