package com.bs.bean;

public class User {
	private Integer uid;//�û����
	private String uname;//�û��ʺ�
	private String upwd;//�û�����
	private String urealname;//��ʵ����
	private String uregdt;//ע������
	private String uphone;//�û��绰
	private Integer urole;//�û���ɫ
	private String umark;//�û���ע
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpwd() {
		return upwd;
	}
	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}
	public String getUrealname() {
		return urealname;
	}
	public void setUrealname(String urealname) {
		this.urealname = urealname;
	}
	public String getUregdt() {
		return uregdt;
	}
	public void setUregdt(String uregdt) {
		this.uregdt = uregdt;
	}
	public String getUphone() {
		return uphone;
	}
	public void setUphone(String uphone) {
		this.uphone = uphone;
	}
	public Integer getUrole() {
		return urole;
	}
	public void setUrole(Integer urole) {
		this.urole = urole;
	}
	public String getUmark() {
		return umark;
	}
	public void setUmark(String umark) {
		this.umark = umark;
	}
	
}
